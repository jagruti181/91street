<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Json extends CI_Controller 
{
	
	function savequantity()
	{
		$product=$this->input->get_post('product');
		$quantity=$this->input->get_post('quantity');
		$data["message"]=$this->product_model->savequantity($product,$quantity);
		$this->load->view("json",$data);
	}
    
    /*frontend apis*/
    public function getmaincategory()
    {
        $data['message']=$this->category_model->getmaincategory();
		$this->load->view('json',$data);
    }
    
    public function saveshoppingbag()
    {
        $user=$this->input->get_post('user');
        $category=$this->input->get_post('category');
        $data['message']=$this->user_model->saveshoppingbag($user,$category);
		$this->load->view('json',$data);
    }
   
    public function myshoppingbag()
    {
        $user=$this->input->get_post('user');
        $data['message']=$this->user_model->myshoppingbag($user);
	$this->load->view('json',$data);
    }
    
    public function getsubcategory()
    {

        $id=$this->input->get_post('id');
        //console.log($id);
        $data['message']=$this->category_model->getsubcategory($id);
		$this->load->view('json',$data);
    }
    
    public function getallcategories()
    {
        $data['message']=$this->category_model->getallcategories();
		$this->load->view('json',$data);
    }
    public function viewcategory()
    {
        $data['message']=$this->category_model->viewcategory();
		$this->load->view('json',$data);
    }
    public function getallmalls()
    {
        $data['message']=$this->mall_model->getallmalls();
		$this->load->view('json',$data);
    }
    
    public function getallbrands()
    {
        $data['message']=$this->brand_model->getallbrands();
		$this->load->view('json',$data);
    }
    public function getallbrandswithoffers()
    {
        $data['message']=$this->brand_model->getallbrandswithoffers();
		$this->load->view('json',$data);
    }
    
    public function getallbrandswithcategories()
    {
        $data['message']=$this->brand_model->getallbrandswithcategories();
		$this->load->view('json',$data);
    }
    
    //Get all Stores by Brandid
    public function getallstoresbybrandid()
    {
        $brandid=$this->input->get_post('id');
        $data['message']=$this->store_model->getallstoresbybrandid($brandid);
		$this->load->view('json',$data);
    }
    //stores
    public function getallstores()
    {
        $data['message']=$this->store_model->getallstores();
		$this->load->view('json',$data);
    }
    public function getallstoreswithoffers()
    {
        $data['message']=$this->store_model->getallstoreswithoffers();
		$this->load->view('json',$data);
    }
    
    public function getallstoreswithcategories()
    {
        $data['message']=$this->store_model->getallstoreswithcategories();
		$this->load->view('json',$data);
    }
//    
//    public function getallstoreswithcategories()
//    {
//        $data['message']=$this->store_model->getallstoreswithcategories();
//		$this->load->view('json',$data);
//    }
    public function getuserbyid()
    {
        $userid=$this->input->get_post('userid');
        $data['message']=$this->user_model->getuserbyid($userid);
		$this->load->view('json',$data);
    }
    
    public function getstorebyid()
    {
        $storeid=$this->input->get_post('storeid');
        $data['message']=$this->store_model->getuserbyid($storeid);
		$this->load->view('json',$data);
    }
    public function createshoppingbag()
    {
        $userid=$this->input->get_post('userid');
        $categoryid=$this->input->get_post('category');
        $data['message']=$this->user_model->getuserbyid($userid,$categoryid);
		$this->load->view('json',$data);
    }
    //
    
    public function getstorebycategory()
    {
        $categoryid=$this->input->get_post('id');
        $data['message']=$this->store_model->getstorebycategory($categoryid);
		$this->load->view('json',$data);
    }
     public function getstorebystoreid()
    {
        $storeid=$this->input->get_post('id');
        $userid=$this->input->get_post('userid');
        $data['message']=$this->store_model->getstorebystoreid($storeid,$userid);
		$this->load->view('json',$data);
    }
    
    //search
    
    public function getbrandsearch()
    {
//        $storeid=$this->input->get_post('id');
        $brandname=$this->input->get_post('brand');
        $data['message']=$this->brand_model->getbrandsearch($brandname);
		$this->load->view('json',$data);
    }
    
    //create frontend user
    
    public function createuser()
    {
//        echo "insert in controller";
        $name=$this->input->get_post('name');
        $sirname=$this->input->get_post('sirname');
        $email=$this->input->get_post('email');
        $password=$this->input->get_post('password');
        $data['message']=$this->user_model->createfrontenduser($name,$sirname,$email,$password);
		$this->load->view('json',$data);
    }
    //rating
    
    public function addrating()
    {
        $userid=$this->input->get_post('userid');
        $rating=$this->input->get_post('rating');
        $storeid=$this->input->get_post('storeid');
        $data['message']=$this->store_model->addrating($userid,$storeid,$rating);
		$this->load->view('json',$data);
    }
    //like
    
    public function addlike()
    {
        $userid=$this->input->get_post('userid');
        $like=$this->input->get_post('like');
        $brandid=$this->input->get_post('brandid');
        $data['message']=$this->brand_model->addlike($userid,$brandid,$like);
		$this->load->view('json',$data);
    }
    
    //login
    
    public function checkfrontendlogin()
    {
        $email=$this->input->get_post('email');
        $password=$this->input->get_post('password');
        $data['message']=$this->user_model->checkfrontendlogin($email,$password);
		$this->load->view('json',$data);
    }
    
    public function getbanner()
    {
        $data['message']=$this->imagegallery_model->getbanner();
		$this->load->view('json',$data);
    }
}
?>